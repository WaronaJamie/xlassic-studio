# Welcome Flow — XlassicStudio

**A 5-email onboarding sequence for SaaS and digital products.**

The exact sequence that turns new signups into active users. Five hand-coded emails designed to introduce your product, build trust, and move people toward their first real win.

---

## What's inside

| Folder | Contents |
|---|---|
| `html/` | Production-ready HTML files. Drop straight into your ESP. |
| `mjml/` | Editable MJML source. Change once, re-export all 5 to HTML. |
| `assets/` | Placeholder images and icons you can swap for your own. |
| `README.md` | This file. |
| `LICENSE.md` | Single-use commercial license. |

### The 5 emails

| # | File | Purpose |
|---|---|---|
| 01 | `01-welcome.html` | Introduce the brand and set expectations |
| 02 | `02-feature-intro.html` | Show what the product can do |
| 03 | `03-social-proof.html` | Build trust with quotes and stats |
| 04 | `04-common-questions.html` | Handle objections with FAQ-style answers |
| 05 | `05-re-engage.html` | Win back subscribers who haven't acted yet |

---

## Quick start

### Option 1 — Use the HTML (fastest)

1. Open any file in `html/` in your email service provider (Mailchimp, Klaviyo, Resend, Loops, Beehiiv, etc.).
2. Find-and-replace the merge tags (see below) with your ESP's syntax.
3. Swap the placeholder images for your own.
4. Send a test to yourself.

That's it. Every HTML file is production-ready.

### Option 2 — Edit with MJML (best for customization)

MJML is a markup language that compiles to bulletproof HTML. Edit the design once, re-export to email-safe HTML.

**Three ways to use it:**

**A. Browser (no install)**

1. Go to [mjml.io/try-it-live](https://mjml.io/try-it-live)
2. Paste any file from `mjml/`
3. Edit on the left, watch the preview update on the right
4. Click **"Copy HTML"** to get the compiled email

**B. VS Code (recommended for ongoing work)**

1. Install the **MJML** extension by MJML (search "mjml" in the Extensions panel)
2. Open any `.mjml` file
3. Right-click the file → **MJML: Copy HTML** or **MJML: Export HTML**
4. A new `.html` file appears next to it

**C. Command line**

```bash
npm install -g mjml
mjml 01-welcome.mjml -o 01-welcome.html
