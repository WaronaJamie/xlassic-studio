# Commercial License — Welcome Flow

Copyright © 2026 XlassicStudio. All rights reserved.

## You may

- Use these templates for unlimited personal or client projects
- Modify the templates however you like
- Combine them with other templates you own

## You may NOT

- Resell, redistribute, or share the templates as-is or modified
- Claim authorship of the original template design
- Include the templates in a competing product
- Upload them to a public repository or file-sharing site

## Support window

6 months of email support from the date of purchase.
Contact: xlassicandcodie@gmail.com

## No warranty

Templates are provided "as is". While tested across major email
clients, XlassicStudio is not liable for rendering issues caused by
third-party services or client updates.
